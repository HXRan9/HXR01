﻿/**
 *@title:Operating system experiment
 *@description:test1.2.3
 *@author: HeXiaoran
 *@date: 2019/4/17
 *${tags}
 */ 


#include<stdio.h>
#define MAX 10
struct task_struct
{
    char name[10];/*进程名称*/
    float arrivetime;/*到达时间*/
    float starttime;/*开始运行时间*/
    float runtime;/*运行时间*/
	float zztime1;//周转时间
	float dzztime1;//带权周转时间
    float finishtime;/*运行结束时间*/
    int runflag;/*调度标志*/
    int startflag; //是否为第一次开始调度
} tasks[MAX];
    int counter; /*实际进程个数*/
    int pinput();
    int timecounter=0;
    int poutput(); /*调度结果输出*/
    int time();
    int charge();//判断是否所有的进程都被执行过
    int choose();//选择可以运行的最短时间进程
	int choose1();//选择可以运行的响应比最高进程
int choose1()
{
   int j,i;      /******计数****/
   int co=1;//用来返回运行时间最短的数组下标
   float restio;  //求最高响应比
   if(tasks[1].arrivetime<=tasks[0].finishtime)
	   restio=tasks[0].finishtime-tasks[1].arrivetime;
   else
	   restio=0;
   float T2=tasks[0].finishtime;
   for(j=1;j<counter;j++)
   {
    if(tasks[j].arrivetime<=T2&&tasks[j].runflag==0)
         tasks[j].startflag=1;

   }
   for(i=2;i<counter;i++)
   {     float restio1=(tasks[i].arrivetime-T2)/tasks[i].runtime;
         if(tasks[i].startflag==1&&tasks[i].runflag==0&&restio1>restio)
		 {co=i;
		  T2=tasks[i].finishtime;
		 
		 
		 }
		 else
			 continue;
   
   }
   return co;

}
int choose()
{   int j;      /******计数****/
   int co=1;//用来返回运行时间最短的数组下标
   float time03=tasks[1].runtime;
   for(j=2;j<counter;j++)
   {if((tasks[j].runtime<time03)&&(tasks[j].runflag==0))
   {co=j;
    time03=tasks[j].runtime;
   }
         
   }
   return co;
   
}
int time()
{
    float temp=0;//用来记录时间片已用长度
    int i;
    int j=0;
    int k=0;
    struct task_struct copy_task[MAX];//备份
    for(i=0; i<counter; i++)
    {
      copy_task[j++]=tasks[i];//对进程的初始化信息备份
    }
    temp=tasks[0].arrivetime;//temp=第一个进程的到达时间
    while(charge())//while条件，charge为0跳出（说明进程都已经全部执行完毕），为1进入（进程还未执行完毕，继续执行）
    {
      for(i=0; i<counter; i++)
   {
    if(tasks[i].arrivetime>temp)//如果第i个的到达时间大于第一个的到达时间，则将第i个的到达时间与temp交换，更新temp的记录，但是第一次运行的时候不走这一步
    {
    temp=tasks[i].arrivetime;
    }
    if(tasks[i].runflag==0)//第i个进程还未结束
    {
      if(tasks[i].startflag==0)//该条件成立则说明，该进程是第一次执行，记录开始执行时间
       {
         tasks[i].starttime=temp;//第一个进程的到达时间为temp
         tasks[i].startflag=1;//运行完上一步后记录该进程已经不是第一次运行了
       }
    if(tasks[i].runtime/timecounter>1)//，运行时间除以时间片长度，说明至少有两倍的时间片未执行
   {
        tasks[i].runtime=tasks[i].runtime-timecounter;//剩余运行时间就等于原来运行时间减去一个时间片长度
        temp=temp+timecounter;//temp继续记录已用的时间片长度
   }
   else if(tasks[i].runtime-timecounter==0)//即运行时间除以时间片长度为1，该进程剩下的刚好是一个时间片长度，说明该进程只需在运行一一步就可以运行完毕
   {
      temp=temp+timecounter;//temp加上最后一个时间片长度就为该进程的结束时间
      tasks[i].finishtime=temp;
      tasks[i].runflag=1;//标记该进程已经执行完毕
      tasks[i].runtime=copy_task[i].runtime;//为了计算周转时间，运行时间从备份里面还原到最开始的运行时间
   }
    else//仅剩下不足一倍的时间片，则剩余运行时间除以时间片长度<1
  {
   temp=temp+tasks[i].runtime;//剩余运行时间不够一个时间片长度，则结束时间等于temp加上该进程的运行时间
   tasks[i].finishtime=temp;
   tasks[i].runflag=1;//标记该进程已经运行完毕
   tasks[i].runtime=copy_task[i].runtime;
  }
  }
 }
}
      return 0;
}
int charge()//判断是否全部进程都执行完毕
{
     int k;
     int superflag=0;//判断是否全部的进程都执行完毕
     for(k=0; k<counter; k++)
 {
  if(tasks[k].runflag==0)
 {
   superflag=1;
   return superflag;
    break;
 }
else
    {
   superflag=0;
    }
 }
   return superflag;
}
int pinput() /*进程参数输入*/
{
    int i;
    printf("请输入进程个数:\n");
    scanf("%d",&counter);

    for(i=0; i<counter; i++)
{
     printf("******************************************\n");
     printf("请输入进程名称、到达时间、运行时间：（中间用空格隔开）\n");
     scanf("%s%f%f",tasks[i].name,&tasks[i].arrivetime,&tasks[i].runtime);
     tasks[i].starttime=0;
     tasks[i].finishtime=0;
     tasks[i].runflag=0;//运行是否结束
     tasks[i].startflag=0;//是否首次被执行
}
        return 0;
}
int poutput() /*调度结果输出*/
{
    int i;
    float zztime=0,f1,w=0,f2,avzztime=0;        //f1、f2用来计算周转时间和带权周转时间
    printf("进程名 到达时间 运行时间 开始时间     结束时间 周转时间 带权周转时间\n");
   for(i=0; i<counter; i++)
{
   f1=tasks[i].finishtime-tasks[i].arrivetime;
   zztime+=f1;
  
   f2=f1/tasks[i].runtime;
   avzztime+=f2;
   printf("%s\t%5.3f\t %5.3f\t  %5.3f       %5.3f\t %5.3f\t  %5.3f\t\n",tasks[i].name,tasks[i].arrivetime,tasks[i].runtime,tasks[i].starttime,tasks[i].finishtime,f1,f2);
}
      printf("平均周转时间=%5.2f\n",zztime/counter);
	  printf("平均带权周转时间=%5.2f\n",avzztime/counter);
      return 0;
}
void main()
{  int c;         //判断选择的进程调度算法
   
   printf("请选择进程调度算法:\n（1）先来先服务调度选1\n（2）时间片轮转调度算法选2\n（3）短作业优先调度算法选3\n请输入你的选择：");
   printf("请选择进程调度算法：");
   scanf("%d",&c);//用来判断选用哪种算法



   /************************先来先服务调度算法**********************/
   if(c==1)
   {
    pinput();
	printf("先来先服务算法:\n\n");
	int i;
    for(i=1;i<=counter;i++)
	  {
	  if(i==1)
	   {tasks[i-1].starttime=tasks[i-1].arrivetime;
	    tasks[i-1].finishtime=tasks[i-1].arrivetime+tasks[i-1].runtime;
		//tasks[i-1].aaa=tasks[i-1].overtime-tasks[i-1].arr_time;
		//tasks[i-1].bbb=process[i-1].aaa/tasks[i-1].usetime;
	   }
	   else
	       { if(tasks[i-1].arrivetime<=tasks[i-2].finishtime)     //判断新的进程在上一个进程完成之前到来
	          {tasks[i-1].starttime=tasks[i-2].finishtime;
	           tasks[i-1].finishtime=tasks[i-1].starttime+tasks[i-1].runtime;
			   //tasks[i-1].aaa=tasks[i-1].overtime-process[i-1].arr_time;
			   //tasks[i-1].bbb=tasks[i-1].aaa/process[i-1].usetime;

	          }
		   else                  /*********上一个进程完成之后新的进程才到***/               
		     {
	           tasks[i-1].starttime=tasks[i-1].arrivetime;
			   tasks[i-1].finishtime=tasks[i-1].starttime+tasks[i-1].runtime;
	           //tasks[i-1].aaa=tasks[i-1].overtime-process[i-1].arr_time;
			   //tasks[i-1].bbb=tasks[i-1].aaa/process[i-1].usetime;
	          }
           }
	  }
    poutput();
   
   
   
   }
   /************************时间片调度算法*******************************/
   if(c==2)
   {printf("请输入时间片长度:");
    scanf("%d",&timecounter);
    pinput();
    printf("时间片轮转算法:\n\n");
    time();
    poutput();
   }



   /************************短作业优先调度算法******************************/
   if(c==3)
   {
    pinput();
	printf("短作业优先调度算法:\n\n");
	int i;
	float a=0,b=0;     //用来计算周转时间，带权周转时间
	//int m;       //判断执行完第一个之后该执行哪一个
	//int k;       //用来判断程序是都执行完
	

    
	    tasks[0].starttime=tasks[0].arrivetime;
	    tasks[0].finishtime=tasks[0].arrivetime+tasks[0].runtime;
		//tasks[i-1].aaa=tasks[i-1].overtime-tasks[i-1].arr_time;
		//tasks[i-1].bbb=process[i-1].aaa/tasks[i-1].usetime;
		tasks[0].zztime1=tasks[0].finishtime-tasks[0].arrivetime;
		tasks[0].dzztime1=tasks[0].zztime1/tasks[0].runtime;
		tasks[0].runflag=1;
		printf("进程名 到达时间 运行时间 开始时间     结束时间 周转时间 带权周转时间\n");
		printf("%s\t%5.3f\t %5.3f\t  %5.3f\t%5.3f\t %5.3f\t  %5.3f\t\n",tasks[0].name,tasks[0].arrivetime,tasks[0].runtime,tasks[0].starttime,tasks[0].finishtime,tasks[0].zztime1,tasks[0].dzztime1);
        

		/*******deal**************************************/
		for(i=1;i<counter;i++)   
		{
		tasks[i].runflag=0;
		}
		int m=1;//判断进程是否都运行过
		int ca;
        
		float T=tasks[0].finishtime;   //用来记录总时间
		

		if(m!=counter)     
		{for(i=1;i<counter;i++)
		       {   if(tasks[i].startflag==0)        
			              
		          {   
					  ca=choose();
                 
					  if(tasks[ca].arrivetime<=T)     //挑选出未执行的最短时间进程，如果在上一个进程完成之前到达
				   {
				       tasks[ca].starttime=T;
					   tasks[ca].finishtime= tasks[ca].starttime+tasks[ca].runtime;
					   tasks[ca].zztime1=tasks[ca].finishtime-tasks[ca].arrivetime;
		               tasks[ca].dzztime1=tasks[ca].zztime1/tasks[ca].runtime;
					   
				       T=tasks[ca].finishtime;
				       tasks[ca].runflag=1;
				       m=m+1;
					   printf("%s\t%5.3f\t %5.3f\t  %5.3f\t%5.3f\t %5.3f\t  %5.3f\t\n",tasks[ca].name,tasks[ca].arrivetime,tasks[ca].runtime,tasks[ca].starttime,tasks[ca].finishtime,tasks[ca].zztime1,tasks[ca].dzztime1);
				      
				   
				   }
				   else 
				   {
					   tasks[ca].starttime=tasks[ca].arrivetime;
					   tasks[ca].finishtime= tasks[ca].starttime+tasks[ca].runtime;
					   tasks[ca].zztime1=tasks[ca].finishtime-tasks[ca].arrivetime;
		               tasks[ca].dzztime1=tasks[ca].zztime1/tasks[ca].runtime;
					   
				       T=tasks[ca].finishtime;
				       tasks[ca].runflag=1;
				       m=m+1;
					   printf("%s\t%5.3f\t %5.3f\t  %5.3f\t%5.3f\t %5.3f\t  %5.3f\t\n",tasks[ca].name,tasks[ca].arrivetime,tasks[ca].runtime,tasks[ca].starttime,tasks[ca].finishtime,tasks[ca].zztime1,tasks[ca].dzztime1);
				   
					  
					  
					  
					  
					  
					  
					  
				   }
		         }
			   else   
				   continue;
		
		
		       }
		}
	              for(i=0;i<counter;i++)
	       {
	
	           a=a+tasks[i].zztime1;
			   b=b+tasks[i].dzztime1;
	
	
	       }
      printf("平均周转时间=%5.2f\n",a/counter);
	  printf("平均带权周转时间=%5.2f\n",b/counter);
   }


   /*************************最高响应比优先调度算法****************************/
   
}